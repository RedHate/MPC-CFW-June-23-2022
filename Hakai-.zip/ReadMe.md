# MPC CFW 2.11.1
MPC software 2.11.1
Force software 3.1.1.3
Ultros / Zangetsu 2021/2022
Still doesn't work for MPC Live 2 users
Only tested on MPC-One so far... again use at your own risk.
By now those who are going to use this will know how to use it... instructions shishsmuctions. Figure it out bud.
